-- Jalankan di Supabase SQL Editor atau melalui Supabase CLI.
-- Semua tabel data pengguna dibatasi dengan Row Level Security.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.savings_goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Target tabungan',
  target_amount numeric(15,2) not null check (target_amount > 0),
  current_amount numeric(15,2) not null default 0 check (current_amount >= 0),
  monthly_amount numeric(15,2) not null check (monthly_amount > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.calculations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tool text not null check (tool in ('tabungan','diskon','keuntungan')),
  inputs jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.cv_drafts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'CV saya',
  content jsonb not null default '{}'::jsonb,
  template text not null default 'clean' check (template in ('clean','classic')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists savings_goals_user_id_idx on public.savings_goals(user_id);
create index if not exists calculations_user_created_idx on public.calculations(user_id, created_at desc);
create index if not exists cv_drafts_user_updated_idx on public.cv_drafts(user_id, updated_at desc);

alter table public.profiles enable row level security;
alter table public.savings_goals enable row level security;
alter table public.calculations enable row level security;
alter table public.cv_drafts enable row level security;

create policy "Users can view own profile" on public.profiles for select to authenticated using ((select auth.uid()) = id);
create policy "Users can insert own profile" on public.profiles for insert to authenticated with check ((select auth.uid()) = id);
create policy "Users can update own profile" on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "Users can delete own profile" on public.profiles for delete to authenticated using ((select auth.uid()) = id);

create policy "Users manage own savings goals" on public.savings_goals for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users manage own calculations" on public.calculations for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users manage own CV drafts" on public.cv_drafts for all to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- Membuat profil dasar saat pengguna baru dibuat.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Catatan: jangan menonaktifkan RLS dan jangan pernah mengekspos service_role key di browser.