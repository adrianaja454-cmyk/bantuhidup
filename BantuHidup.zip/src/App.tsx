import { Routes, Route } from 'react-router-dom'
import { Layout } from './components/Layout'
import Home from './pages/Home'
import Tools from './pages/Tools'
import { Savings, Discount, Profit } from './pages/Calculators'
import CV from './pages/CV'
import { Guides, GuideDetail } from './pages/Guides'
import Learning from './pages/Learning'
import Account from './pages/Account'
import { About, Legal } from './pages/Info'
import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
function NotFound(){return <section className="section container empty-state not-found"><span className="eyebrow">404 · Halaman tidak ditemukan</span><h1 className="page-title">Sepertinya kamu tersesat.</h1><p>Halaman yang dicari tidak tersedia atau sudah dipindahkan.</p><Link to="/" className="btn btn-primary"><ArrowLeft size={16}/> Kembali ke beranda</Link></section>}
export default function App(){return <Routes><Route element={<Layout/>}><Route index element={<Home/>}/><Route path="/alat" element={<Tools/>}/><Route path="/alat/tabungan" element={<Savings/>}/><Route path="/alat/diskon" element={<Discount/>}/><Route path="/alat/keuntungan" element={<Profit/>}/><Route path="/alat/cv" element={<CV/>}/><Route path="/panduan" element={<Guides/>}/><Route path="/panduan/:id" element={<GuideDetail/>}/><Route path="/belajar" element={<Learning/>}/><Route path="/akun" element={<Account/>}/><Route path="/tentang" element={<About/>}/><Route path="/privasi" element={<Legal type="privacy"/>}/><Route path="/syarat" element={<Legal type="terms"/>}/><Route path="*" element={<NotFound/>}/></Route></Routes>}