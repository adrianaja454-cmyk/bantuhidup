import { useState } from 'react'
import { Link, NavLink, Outlet } from 'react-router-dom'
import { Menu, X, HeartHandshake, ArrowUpRight } from 'lucide-react'
export function Layout() {
 const [open,setOpen] = useState(false)
 const links = [['Beranda','/'],['Semua Alat','/alat'],['Panduan','/panduan'],['Belajar Gratis','/belajar'],['Tentang Kami','/tentang']]
 return <div className="app-shell">
  <header className="topbar"><div className="container nav-inner">
   <Link to="/" className="brand" onClick={()=>setOpen(false)}><span className="brand-mark"><HeartHandshake size={21}/></span><span>Bantu<span className="brand-blue">Hidup</span></span></Link>
   <button className="icon-btn mobile-toggle" aria-label="Buka navigasi" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
   <nav className={open?'nav-links is-open':'nav-links'} aria-label="Navigasi utama">{links.map(([label,path])=><NavLink key={path} to={path} onClick={()=>setOpen(false)}>{label}</NavLink>)}<Link className="nav-login" to="/akun" onClick={()=>setOpen(false)}>Login <ArrowUpRight size={15}/></Link></nav>
  </div></header>
  <main><Outlet/></main>
  <footer className="footer"><div className="container footer-grid"><div><Link to="/" className="brand"><span className="brand-mark"><HeartHandshake size={20}/></span><span>Bantu<span className="brand-blue">Hidup</span></span></Link><p className="muted footer-copy">Alat sederhana dan sumber tepercaya untuk membantu langkah sehari-hari.</p></div><div><b>Jelajahi</b><Link to="/alat">Semua alat</Link><Link to="/panduan">Panduan</Link><Link to="/belajar">Belajar gratis</Link></div><div><b>Informasi</b><Link to="/tentang">Tentang kami</Link><Link to="/privasi">Kebijakan privasi</Link><Link to="/syarat">Syarat penggunaan</Link></div><div><b>Kontak</b><a href="mailto:halo@bantuhidup.id">halo@bantuhidup.id</a><span className="muted small">Email contoh — sesuaikan sebelum publikasi.</span></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} BantuHidup</span><span>Dibuat untuk membantu, bukan mempersulit.</span></div></footer>
 </div>
}