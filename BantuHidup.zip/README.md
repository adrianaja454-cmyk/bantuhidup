# BantuHidup

Platform berbahasa Indonesia berisi alat gratis untuk keuangan, usaha, CV, panduan karier, dan sumber belajar.

## Teknologi

- React + Vite + TypeScript
- Tailwind CSS v4 (Vite plugin) dan CSS responsif
- React Router
- Supabase Auth + PostgreSQL + Row Level Security
- jsPDF untuk ekspor CV PDF
- Lucide React untuk ikon

## Menjalankan secara lokal

Persyaratan: Node.js 20.19+ atau 22.12+ dan npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Buka URL lokal yang dicetak Vite. Tanpa konfigurasi Supabase, kalkulator, artikel, direktori belajar, dan ekspor PDF tetap dapat digunakan. Login serta penyimpanan cloud tidak aktif sampai Supabase dikonfigurasi; antarmuka akan menjelaskan kondisi tersebut.

## Konfigurasi Supabase

1. Buat proyek pada https://supabase.com/.
2. Di **Project Settings → API**, salin Project URL dan publishable key (atau anon key legacy).
3. Isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` di `.env`. Variabel `VITE_` tersedia pada browser, jadi hanya gunakan publishable/anon key yang memang dirancang untuk akses klien. Jangan pernah gunakan `service_role` atau secret key.
4. Buka SQL Editor di dashboard Supabase dan jalankan seluruh isi `supabase/migrations/202610100001_initial_schema.sql`.
5. Di Authentication → URL Configuration, atur Site URL ke alamat pengembangan (misalnya `http://localhost:5173`) dan tambahkan redirect URL yang sesuai untuk lingkungan lokal dan produksi.
6. Atur pengiriman email/SMTP sesuai kebutuhan. Verifikasi email dapat diatur dari Authentication → Providers → Email.
7. Mulai ulang server Vite setelah mengubah `.env`.

### Data dan keamanan

- Tabel `profiles`, `savings_goals`, `calculations`, dan `cv_drafts` memakai RLS dan kebijakan berbasis `auth.uid()`.
- Kalkulator tabungan dapat menyimpan ringkasan input ke tabel `calculations` jika pengguna sudah login.
- Dashboard membaca riwayat kalkulasi dan draft CV yang tersimpan.
- Draft CV pada UI saat ini belum mempunyai alur simpan/edit lengkap; tombol unduh CV membuat PDF di browser dan tidak mengirim data ke server. Untuk mengaktifkan penyimpanan draft, implementasikan form upsert/select/update/delete ke `cv_drafts` dengan `user_id` dari sesi Supabase.
- Tabel `savings_goals` disiapkan untuk fitur progres tabungan persisten; formulir saat ini menghitung target langsung dan belum menyinkronkan target ke tabel itu.
- Penghapusan akun Supabase memerlukan proses server-side/admin yang aman; jangan mencoba menghapus akun menggunakan service key dari frontend.
- Kebijakan privasi dan alamat kontak masih berupa draf/contoh dan perlu disesuaikan sebelum peluncuran.

## Build produksi

```bash
npm run build
npm run preview
```

Folder `dist/` adalah hasil build.

## Deploy publik

### Vercel
1. Push repositori ke GitHub.
2. Impor proyek pada Vercel.
3. Framework: Vite; build command `npm run build`; output directory `dist`.
4. Tambahkan `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` pada Environment Variables.
5. Tambahkan rewrite SPA agar seluruh rute React Router diarahkan ke `index.html` (file `vercel.json` disediakan).

### Netlify
Build command `npm run build`, publish directory `dist`; file `_redirects` disediakan untuk fallback SPA. Isi environment variables di pengaturan situs.

## Fitur yang diimplementasikan

- Beranda responsif dengan pencarian alat.
- Katalog alat dengan filter kategori.
- Kalkulator tabungan dengan progres, validasi, dan opsi simpan kalkulasi.
- Kalkulator diskon, perubahan persentase, dan persentase angka.
- Kalkulator biaya/omzet/laba/margin usaha.
- Pembuat CV dengan pratinjau langsung, dua gaya visual, dan ekspor PDF.
- Artikel panduan dengan pencarian, filter, dan halaman detail.
- Direktori sumber belajar gratis dengan tautan penyedia.
- Form login/daftar/reset password via Supabase Auth.
- Dashboard riwayat, hapus kalkulasi, akses CV, pengaturan/reset password.
- Halaman tentang, kebijakan privasi, syarat, dan 404.

## Batasan yang diketahui

- Belum ada pengujian otomatis/e2e dalam paket ini. Jalankan `npm install` lalu `npm run build` sebelum deploy.
- Tautan belajar menuju situs penyedia yang dikenal, namun ketersediaan dan isi dapat berubah; verifikasi kembali saat publikasi.
- Untuk produksi, lengkapi penyimpanan draft CV, pengelolaan target tabungan, edit profil, penghapusan akun yang aman, dan tinjauan legal.
